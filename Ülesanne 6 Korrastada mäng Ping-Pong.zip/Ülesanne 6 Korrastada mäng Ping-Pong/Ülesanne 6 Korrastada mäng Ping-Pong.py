import pygame  # Impordime pygame'i mooduli
import sys  # Impordime sys mooduli
import os  # Impordime os mooduli

pygame.init()  # Initsialiseerime pygame'i
pygame.mixer.init()  # Initsialiseerime Pygame'i helisüsteemi

# Määrame mänguakna laiuse ja kõrguse
screen_width = 640
screen_height = 480
background_color = (240, 240, 240)  # Määrame taustavärvi RGB-koodina

ball_radius = 10  # Määrame palli raadiuse
# Laadime palli pildifaili
ball_image = pygame.image.load(os.path.join('ball.png'))
# Skaleerime palli pildi vastavalt raadiusele
ball_image = pygame.transform.scale(ball_image, (ball_radius * 2, ball_radius * 2))
# Loome palli jaoks piirava ristküliku ja määrame selle keskpunkti
ball_rect = ball_image.get_rect(center=(screen_width // 2, screen_height // 2))
ball_speed_x = 2  # Määrame palli liikumiskiiruse x-suunas
ball_speed_y = 2  # Määrame palli liikumiskiiruse y-suunas

# Määrame aluse laiuse ja kõrguse
paddle_width = 120
paddle_height = 20
# Laadime aluse pildifaili
paddle_image = pygame.image.load(os.path.join('pad.png'))
# Skaleerime aluse pildi vastavalt määratud laiusele ja kõrgusele
paddle_image = pygame.transform.scale(paddle_image, (paddle_width, paddle_height))
# Loome aluse jaoks piirava ristküliku ja määrame selle keskpunkti
paddle_rect = paddle_image.get_rect(center=(screen_width // 2, int(screen_height / 1.5)))

score = 0  # Alustame mängu skoori nullist

# Loome mänguakna määratud laiuse ja kõrgusega
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Pallimäng")  # Määrame mänguakna pealkirja

clock = pygame.time.Clock()  # Loome kellaobjekti, et hoida mängu FPS konstantse

# Heliefekti laadimine
hit_sound_path = 'hit_sound.wav'
if os.path.exists(hit_sound_path):  # Kontrollime, kas helifail eksisteerib
    hit_sound = pygame.mixer.Sound(hit_sound_path)  # Laadime helifaili
else:
    print(f"Hit sound file '{hit_sound_path}' not found.")  # Teatame, kui helifaili ei leitud

# Funktsioon palli joonistamiseks ekraanile
def draw_ball():
    screen.blit(ball_image, ball_rect)

# Funktsioon aluse joonistamiseks ekraanile
def draw_paddle():
    screen.blit(paddle_image, paddle_rect)

# Funktsioon skoori joonistamiseks ekraanile
def draw_score():
    font = pygame.font.Font(None, 36)  # Loome fondiobjekti
    text = font.render("Score: " + str(score), True, (0, 0, 0))  # Loome teksti, mis näitab skoori
    screen.blit(text, (10, 10))  # Joonistame skoori ekraanile

# Funktsioon kokkupõrke tuvastamiseks
def collision_detection():
    global score, ball_speed_x, ball_speed_y
    if ball_rect.colliderect(paddle_rect):  # Kui pall puudutab alust
        if ball_speed_y > 0:  # Kui pall liigub allapoole
            ball_speed_y = -ball_speed_y  # Muudame palli liikumissuunda
            score += 1  # Suurendame skoori
            hit_sound.play()  # Mängime heliefekti
    if ball_rect.left < 0 or ball_rect.right > screen_width:  # Kui pall puudutab ekraani servi
        ball_speed_x = -ball_speed_x  # Põrge ekraani servast
    if ball_rect.top < 0:  # Kui pall puudutab ekraani ülemist serva
        ball_speed_y = -ball_speed_y  # Põrge ekraani ülemisest servast
    elif ball_rect.bottom > screen_height:  # Kui pall liigub alla ekraanilt välja
        end_game()  # Lõpeta mäng

# Funktsioon palli algseisundi taastamiseks
def reset_ball():
    global ball_rect, ball_speed_x, ball_speed_y
    ball_rect.center = (screen_width // 2, screen_height // 2)  # Taasta palli keskpunkt
    ball_speed_x = 2  # Taasta palli liikumiskiirus x-suunas
    ball_speed_y = 2  # Taasta palli liikumiskiirus y-suunas

# Funktsioon aluse liikumiseks
def move_paddle():
    keys = pygame.key.get_pressed()  # Võtame klahvivajutused
    if keys[pygame.K_LEFT] and paddle_rect.left > 0:  # Kui vasak klahv on all ja alus ei ole vasakus servas
        paddle_rect.move_ip(-paddle_speed, 0)  # Liiguta alust vasakule
    if keys[pygame.K_RIGHT] and paddle_rect.right < screen_width:  # Kui parem klahv on all ja alus ei ole paremas servas
        paddle_rect.move_ip(paddle_speed, 0)  # Liiguta alust paremale

# Funktsioon mängu lõpetamiseks
def end_game():
    pygame.quit()  # Sulge pygame
    sys.exit()  # Lõpeta programmi töö

paddle_speed = 5  # Määrame aluse liikumiskiiruse

# Mängutsükkel
running = True
while running:
    for event in pygame.event.get():  # Käsitse sündmusi
        if event.type == pygame.QUIT:  # Kui kasutaja soovib programmi sulgeda
            running = False  # Peata mängutsükkel

    ball_rect.move_ip(ball_speed_x, ball_speed_y)  # Liiguta palli vastavalt kiirustele

    screen.fill(background_color)  # Täida ekraan taustavärviga
    draw_ball()  # Joonista pall
    move_paddle()  # Liiguta alust
    draw_paddle()  # Joonista alus
    draw_score()  # Joonista skoor
    collision_detection()  # Tuvasta kokkupõrge

    pygame.display.flip()  # Värskenda ekraani
    clock.tick(60)  # Piira mängu FPS 60-ni

pygame.quit()  # Sulge pygame
sys.exit()  # Lõpeta programmi töö
