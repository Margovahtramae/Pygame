# Impordib pygame'i mooduli
import pygame

# Initsialiseerib pygame'i
pygame.init()

# Seab mängu akna pealkirjaks "Ülesanne2"
pygame.display.set_caption("Ülessane2")

# Loob mängu akna suurusega 640x480 pikslit
screen = pygame.display.set_mode((640, 480))

# Laeb taustapildi
bg = pygame.image.load("bg_shop.jpg")

# Laeb müüja pildi ja skaalib selle suuruseks 250x300 pikslit
sell = pygame.image.load("seller.png")
sell = pygame.transform.scale(sell, [250, 300])

# Laeb jutumulli pildi
chat = pygame.image.load("chat.png")

# Initsialiseerib pygame'i fondi
pygame.font.init()

# Loob fondi suurusega 24 punkti
font = pygame.font.Font(pygame.font.match_font("none"), 24)

# Loob teksti pildi, kasutades eelnevalt loodud fonti, valget värvi ja teksti "Tere, Margo-Marten Vahtramäe"
text = font.render("Tere, Margo-Marten Vahtramäe", True, [255,255,255])

# Määrab teksti laiuse ja kõrguse
text_width = text.get_rect().width
text_height = text.get_rect().height

# Seab muutuja "running" väärtuseks "True"
running = True

# Mängutsükkel
while running:
    # Käsitseb sündmusi
    for event in pygame.event.get():
        # Kui kasutaja vajutab sulgemisnuppu
        if event.type == pygame.QUIT:
            # Muudab muutuja "running" väärtuseks "False", mis peatab mängutsükli
            running = False

    # Asetab taustapildi mängu aknale
    screen.blit(bg,[0,0])
    # Asetab müüja pildi mängu aknale koordinaatidele (105,160)
    screen.blit(sell,[105,160])
    # Asetab jutumulli pildi mängu aknale koordinaatidele (245,30)
    screen.blit(chat,[245,30])

    # Arvutab teksti x- ja y-koordinaadid nii, et tekst oleks keskel
    text_x = (screen.get_width() - text_width) // 2
    text_y = (screen.get_height() - text_height) // 2
    # Asetab teksti mängu aknale koordinaatidele (380-text_width/2, 140-text_height/2)
    screen.blit(text, [380-text_width/2,140-text_height/2])

    # Värskendab mänguakent
    pygame.display.flip()

# Lõpetab pygame'i kasutamise
pygame.quit()
