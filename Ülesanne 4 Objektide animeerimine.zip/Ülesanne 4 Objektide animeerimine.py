import pygame
import random

# Ekraani suurus
WIDTH = 640
HEIGHT = 480

# Funktsioon skoori kuvamiseks
def draw_score(screen, score):
    font = pygame.font.Font(None, 36)
    score_text = font.render("Score: " + str(score), True, (255, 255, 255))
    screen.blit(score_text, (10, 10))

# Funktsioon siniste autode loomiseks
def create_blue_cars():
    car_img = pygame.image.load("sinine_auto.png")  # Sinise auto pilt
    car_width, car_height = car_img.get_size()
    x = random.randint(110, WIDTH - car_width - 100)  # X-koordinaadi vahemik
    y = random.randint(-HEIGHT, -car_height)
    return car_img, pygame.Rect(x, y, car_width, car_height)

# Funktsioon punase auto loomiseks
def create_red_car():
    car_img = pygame.image.load("punane_auto.png")  # Punase auto pilt
    car_width, car_height = car_img.get_size()
    x = (WIDTH - car_width) // 2
    y = HEIGHT - car_height - 10
    return car_img, pygame.Rect(x, y, car_width, car_height)

# Funktsioon taustapildi laadimiseks
def load_background():
    return pygame.image.load("taust.jpg")  # Taustapilt

# Funktsioon autode liigutamiseks
def move_cars(red_car_rect, blue_cars, score):
    for car, rect in blue_cars:
        if red_car_rect.colliderect(rect):  # Kontrollime kokkupõrkeid enne liikumist alla
            score += 1
            rect.y = random.randint(-HEIGHT, -50)
            rect.x = random.randint(110, WIDTH - rect.width - 100)  # Uus X-koordinaat
        else:
            rect.y += 5  # Autode kiirus
            if rect.y > HEIGHT:
                rect.y = random.randint(-HEIGHT, -50)
    return score

# Põhifunktsioon
def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Car Game")
    clock = pygame.time.Clock()

    red_car_img, red_car_rect = create_red_car()
    blue_cars = [create_blue_cars() for _ in range(5)]  # Loome 5 sinist autot alguses

    background = load_background()  # Laeme taustapildi

    score = 0

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Liigutame autosid
        for car, rect in blue_cars:
            rect.y += 5  # Autode kiirus
            if rect.y > HEIGHT:
                rect.y = random.randint(-HEIGHT, -50)
                rect.x = random.randint(110, WIDTH - rect.width - 100)  # Uus X-koordinaat
                # Kontrollime kollisiooni enne skoori suurendamist
                if not red_car_rect.colliderect(rect):
                    score += 1

        # Joonistame tausta
        screen.blit(background, (0, 0))

        # Joonistame autod
        screen.blit(red_car_img, red_car_rect)
        for car, rect in blue_cars:
            screen.blit(car, rect)

        # Joonistame skoori
        draw_score(screen, score)

        pygame.display.flip()
        clock.tick(30)

    pygame.quit()

if __name__ == "__main__":
    main()
