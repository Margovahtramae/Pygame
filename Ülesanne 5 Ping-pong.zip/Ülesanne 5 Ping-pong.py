import pygame  # Impordime pygame'i mooduli
import sys  # Impordime sys mooduli
import os  # Impordime os mooduli

# Initsialiseerime pygame'i
pygame.init()

# Mänguakna suurus ja taustavärv
screen_width = 640
screen_height = 480
background_color = (240, 240, 240)  # Heledam taustavärv

# Palli omadused
ball_radius = 10
ball_image = pygame.image.load(os.path.join('ball.png'))  # Laadime palli pildifaili
ball_image = pygame.transform.scale(ball_image, (ball_radius * 2, ball_radius * 2))  # Skaleerime palli pildi
ball_rect = ball_image.get_rect(center=(screen_width // 2, screen_height // 2))  # Loome palli jaoks piirava ristküliku
ball_speed_x = 2  # Palli liikumiskiirus x-suunas
ball_speed_y = 2  # Palli liikumiskiirus y-suunas

# Aluse omadused
paddle_width = 120
paddle_height = 20
paddle_image = pygame.image.load(os.path.join('pad.png'))  # Laadime aluse pildifaili
paddle_image = pygame.transform.scale(paddle_image, (paddle_width, paddle_height))  # Skaleerime aluse pildi
paddle_rect = paddle_image.get_rect(center=(screen_width // 2, int(screen_height / 1.5)))  # Loome aluse jaoks piirava ristküliku
paddle_speed = 5  # Aluse liikumiskiirus

# Tulemused
score = 0  # Alustame mängu nullist

# Initsialiseerime mänguakna
screen = pygame.display.set_mode((screen_width, screen_height))  # Loome mänguakna
pygame.display.set_caption("Pallimäng")  # Määrame mänguakna pealkirja

clock = pygame.time.Clock()  # Loome kellaobjekti, et hoida mängu FPS (kaadrite arv sekundis) konstantse

# Funktsioon palli joonistamiseks
def draw_ball():
    screen.blit(ball_image, ball_rect)  # Joonistame palli ekraanile

# Funktsioon aluse joonistamiseks
def draw_paddle():
    screen.blit(paddle_image, paddle_rect)  # Joonistame aluse ekraanile

# Funktsioon tulemuse joonistamiseks
def draw_score():
    font = pygame.font.Font(None, 36)  # Loome fondiobjekti
    text = font.render("Score: " + str(score), True, (0, 0, 0))  # Loome teksti, mis näitab skoori
    screen.blit(text, (10, 10))  # Joonistame skoori ekraanile

# Põrke tuvastamine
def collision_detection():
    global score, ball_speed_x, ball_speed_y
    if ball_rect.colliderect(paddle_rect):  # Kui pall puudutab alust
        if ball_speed_y > 0:  # Kui pall liigub allapoole
            ball_speed_y = -ball_speed_y  # Muudame palli liikumissuunda
            score += 1  # Suurendame skoori
    if ball_rect.left < 0 or ball_rect.right > screen_width:  # Kui pall puudutab ekraani servi
        ball_speed_x = -ball_speed_x  # Põrge ekraani servast
    if ball_rect.top < 0:  # Kui pall puudutab ekraani ülemist serva
        ball_speed_y = -ball_speed_y  # Põrge ekraani ülemisest servast
    elif ball_rect.bottom > screen_height:  # Kui pall liigub alla ekraanilt välja
        score -= 1  # Vähendame skoori
        reset_ball()  # Taasta palli positsioon

# Funktsioon palli lähtepositsioonile naasmiseks
def reset_ball():
    global ball_rect, ball_speed_x, ball_speed_y
    ball_rect.center = (screen_width // 2, screen_height // 2)  # Taasta palli keskpunkt
    ball_speed_x = 2  # Taasta palli liikumiskiirus x-suunas
    ball_speed_y = 2  # Taasta palli liikumiskiirus y-suunas

# Mängutsükkel
running = True
while running:
    for event in pygame.event.get():  # Käsitse sündmusi
        if event.type == pygame.QUIT:  # Kui kasutaja soovib programmi sulgeda
            running = False  # Peata mängutsükkel

    # Aluse juhtimine
    keys = pygame.key.get_pressed()  # Võta klahvivajutused
    if keys[pygame.K_LEFT]:  # Kui vasak nooleklahv on vajutatud
        paddle_rect.move_ip(-paddle_speed, 0)  # Liiguta alust vasakule
        if paddle_rect.left < 0:  # Kui alus jõuab vasakule ekraani servale
            paddle_rect.left = 0  # Ära lase sellel välja minna
    if keys[pygame.K_RIGHT]:  # Kui parem nooleklahv on vajutatud
        paddle_rect.move_ip(paddle_speed, 0)  # Liiguta alust paremale
        if paddle_rect.right > screen_width:  # Kui alus jõuab paremale ekraani servale
            paddle_rect.right = screen_width  # Ära lase sellel välja minna

    # Palli liikumine
    ball_rect.move_ip(ball_speed_x, ball_speed_y)  # Liiguta palli vastavalt selle kiirustele

    # Tühjendame ekraani ja joonistame elemendid
    screen.fill(background_color)  # Täida ekraan taustavärviga
    draw_ball()  # Joonista pall
    draw_paddle()  # Joonista alus
    draw_score()  # Joonista skoor
    collision_detection()  # Tuvasa palli ja aluse põrke

    pygame.display.flip()  # Värskenda ekraani
    clock.tick(60)  # Piira mängu FPS 60-ni

pygame.quit()  # Sulge pygame'i
sys.exit()  # Lõpeta programmi töö
