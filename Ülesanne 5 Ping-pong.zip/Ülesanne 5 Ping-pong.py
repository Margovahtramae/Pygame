import pygame  
import sys  
import os  

pygame.init()

screen_width = 640
screen_height = 480
background_color = (240, 240, 240)  

ball_radius = 10
ball_image = pygame.image.load(os.path.join('ball.png'))  
ball_image = pygame.transform.scale(ball_image, (ball_radius * 2, ball_radius * 2))  
ball_rect = ball_image.get_rect(center=(screen_width // 2, screen_height // 2))  
ball_speed_x = 2  
ball_speed_y = 2  

paddle_width = 120
paddle_height = 20
paddle_image = pygame.image.load(os.path.join('pad.png'))  
paddle_image = pygame.transform.scale(paddle_image, (paddle_width, paddle_height))  
paddle_rect = paddle_image.get_rect(center=(screen_width // 2, int(screen_height / 1.5)))  

score = 0  

screen = pygame.display.set_mode((screen_width, screen_height))  
pygame.display.set_caption("Pallimäng")  

clock = pygame.time.Clock()  

def draw_ball():
    screen.blit(ball_image, ball_rect)  

def draw_paddle():
    screen.blit(paddle_image, paddle_rect)  

def draw_score():
    font = pygame.font.Font(None, 36)  
    text = font.render("Score: " + str(score), True, (0, 0, 0))  
    screen.blit(text, (10, 10))  

def collision_detection():
    global score, ball_speed_x, ball_speed_y
    if ball_rect.colliderect(paddle_rect):  
        if ball_speed_y > 0:  
            ball_speed_y = -ball_speed_y  
            score += 1  
    if ball_rect.left < 0 or ball_rect.right > screen_width:  
        ball_speed_x = -ball_speed_x  
    if ball_rect.top < 0:  
        ball_speed_y = -ball_speed_y  
    elif ball_rect.bottom > screen_height:  
        score -= 1  
        reset_ball()  

def reset_ball():
    global ball_rect, ball_speed_x, ball_speed_y
    ball_rect.center = (screen_width // 2, screen_height // 2)  
    ball_speed_x = 2  
    ball_speed_y = 2  

# Määratleme paddle_speed muutuja
paddle_speed = 5

# Eemaldame kasutaja juhitava aluse
def move_paddle():
    global paddle_speed
    paddle_rect.move_ip(paddle_speed, 0)
    if paddle_rect.left < 0 or paddle_rect.right > screen_width:
        paddle_speed = -paddle_speed

running = True
while running:
    for event in pygame.event.get():  
        if event.type == pygame.QUIT:  
            running = False  

    ball_rect.move_ip(ball_speed_x, ball_speed_y)  

    screen.fill(background_color)  
    draw_ball()  
    move_paddle()  
    draw_paddle()  
    draw_score()  
    collision_detection()  

    pygame.display.flip()  
    clock.tick(60)  

pygame.quit()  
sys.exit()  
