import pygame  # Impordime pygame mooduli
import random  # Impordime random mooduli
import os  # Impordime os mooduli

pygame.init()  # Initsialiseerime pygame
pygame.mixer.init()  # Initsialiseerime Pygame'i helisüsteemi

# Määrame ekraani laiuse ja kõrguse
screen_width = 640  # Ekraani laius
screen_height = 480  # Ekraani kõrgus

# Määrame värvid
white = (255, 255, 255)  # Valge värv
black = (0, 0, 0)  # Must värv
red = (255, 0, 0)  # Punane värv
green = (0, 255, 0)  # Roheline värv

# Laadime taustamuusika ja heliefektid
pygame.mixer.music.load('background_music.mp3')  # Laadime taustamuusika
pygame.mixer.music.play(-1)  # Mängime taustamuusikat lõputult
eat_sound = pygame.mixer.Sound('eat.mp3')  # Laadime heli, kui madu sööb toitu
bonus_sound = pygame.mixer.Sound('bonus.mp3')  # Laadime heli, kui madu sööb boonustoitu

# Laadime pildifailid ja skaleerime need sobivaks suuruseks
snake_body_img = pygame.image.load('snake_body.png')  # Laadime mao keha pildi
snake_body_img = pygame.transform.scale(snake_body_img, (40, 40))  # Skaleerime mao keha pildi

food_img = pygame.image.load('food.png')  # Laadime toidu pildi
food_img = pygame.transform.scale(food_img, (40, 40))  # Skaleerime toidu pildi

bonus_food_img = pygame.image.load('bonus_food.png')  # Laadime boonustoitu pildi
bonus_food_img = pygame.transform.scale(bonus_food_img, (40, 40))  # Skaleerime boonustoitu pildi

# Määrame mängu kiiruse ja suurused
clock = pygame.time.Clock()  # Loome kellaobjekti, et hoida mängu FPS konstantse
snake_size = 40  # Määrame madu ja toidu suuruse
snake_speed = 5  # Määrame madu kiiruse

font_style = pygame.font.SysFont(None, 35)  # Määrame fondi stiili ja suuruse

# Funktsioon sõnumite kuvamiseks
def message(msg, color, x, y):
    mesg = font_style.render(msg, True, color)  # Loome sõnumi
    screen.blit(mesg, [x, y])  # Kuvame sõnumi ekraanile

# Funktsioon mängu käivitamiseks
def gameLoop():
    game_over = False  # Määrame mängu lõpu oleku
    game_close = False  # Määrame mängu sulgemise oleku

    x1 = screen_width / 2  # Määrame mao algpositsiooni x-koordinaadi
    y1 = screen_height / 2  # Määrame mao algpositsiooni y-koordinaadi

    x1_change = 0  # Määrame mao liikumise x-suunas
    y1_change = 0  # Määrame mao liikumise y-suunas

    snake_List = []  # Loome tühja nimekirja mao segmentide jaoks
    Length_of_snake = 1  # Määrame mao algse pikkuse

    # Määrame toidu ja boonustoitude algpositsioonid
    foodx = round(random.randrange(0, screen_width - snake_size) / 40.0) * 40.0
    foody = round(random.randrange(0, screen_height - snake_size) / 40.0) * 40.0
    bonusx = round(random.randrange(0, screen_width - snake_size) / 40.0) * 40.0
    bonusy = round(random.randrange(0, screen_height - snake_size) / 40.0) * 40.0

    score = 0  # Määrame algse skoori
    bonus_timer = 0  # Määrame boonustoitude ajastuse

    while not game_over:  # Mängutsükkel

        while game_close == True:  # Kui mäng on suletud
            screen.fill(black)  # Täidame ekraani musta värviga
            message("You Lost! Press Q-Quit or C-Play Again", red, screen_width / 8, screen_height / 3)  # Kuvame sõnumi, et mäng on läbi
            pygame.display.update()  # Värskendame ekraani

            for event in pygame.event.get():  # Kontrollime sündmusi
                if event.type == pygame.KEYDOWN:  # Kui klahv on alla vajutatud
                    if event.key == pygame.K_q:  # Kui klahv Q on vajutatud
                        game_over = True  # Lõpetame mängu
                        game_close = False  # Sulgeme mängu
                    if event.key == pygame.K_c:  # Kui klahv C on vajutatud
                        gameLoop()  # Käivitame mängu uuesti

        for event in pygame.event.get():  # Kontrollime sündmusi
            if event.type == pygame.QUIT:  # Kui kasutaja sulgeb mänguakna
                game_over = True  # Lõpetame mängu
            if event.type == pygame.KEYDOWN:  # Kui klahv on alla vajutatud
                if event.key == pygame.K_LEFT:  # Kui klahv LEFT on vajutatud
                    x1_change = -snake_size  # Määrame liikumise x-suunas
                    y1_change = 0  # Nullime liikumise y-suunas
                elif event.key == pygame.K_RIGHT:  # Kui klahv RIGHT on vajutatud
                    x1_change = snake_size  # Määrame liikumise x-suunas
                    y1_change = 0  # Nullime liikumise y-suunas
                elif event.key == pygame.K_UP:  # Kui klahv UP on vajutatud
                    y1_change = -snake_size  # Määrame liikumise y-suunas
                    x1_change = 0  # Nullime liikumise x-suunas
                elif event.key == pygame.K_DOWN:  # Kui klahv DOWN on vajutatud
                    y1_change = snake_size  # Määrame liikumise y-suunas
                    x1_change = 0  # Nullime liikumise x-suunas

        if x1 >= screen_width or x1 < 0 or y1 >= screen_height or y1 < 0:  # Kui madu läheb ekraani piiridest välja
            game_close = True  # Sulgeme mängu
        x1 += x1_change  # Muudame mao x-koordinaati
        y1 += y1_change  # Muudame mao y-koordinaati
        screen.fill(white)  # Täidame ekraani valge värviga
        
        screen.blit(food_img, (foodx, foody))  # Kuvame toidu ekraanile

        if bonus_timer < 500:  # Kuvame boonustoitu ainult teatud ajaks
            screen.blit(bonus_food_img, (bonusx, bonusy))  # Kuvame boonustoitu ekraanile
            bonus_timer += 1  # Suurendame boonustoitude ajastust
        else:
            bonusx = round(random.randrange(0, screen_width - snake_size) / 40.0) * 40.0  # Määrame uue boonustoitu x-koordinaadi
            bonusy = round(random.randrange(0, screen_height - snake_size) / 40.0) * 40.0  # Määrame uue boonustoitu y-koordinaadi
            bonus_timer = 0  # Nullime boonustoitude ajastuse

        snake_Head = [x1, y1]  # Loome mao pea
        snake_List.append(snake_Head)  # Lisame mao pea mao segmentide nimekirja
        if len(snake_List) > Length_of_snake:  # Kui mao pikkus ületab lubatud pikkuse
            del snake_List[0]  # Kustutame esimese segmendi

        for x in snake_List[:-1]:  # Kontrollime, kas madu põrkab kokku iseendaga
            if x == snake_Head:
                game_close = True  # Sulgeme mängu

        # Joonistame mao
        for segment in snake_List:
            screen.blit(snake_body_img, (segment[0], segment[1]))  # Kuvame mao segmendi ekraanile

        pygame.display.update()  # Värskendame ekraani

        if x1 == foodx and y1 == foody:  # Kui madu sööb toitu
            foodx = round(random.randrange(0, screen_width - snake_size) / 40.0) * 40.0  # Määrame uue toidu x-koordinaadi
            foody = round(random.randrange(0, screen_height - snake_size) / 40.0) * 40.0  # Määrame uue toidu y-koordinaadi
            Length_of_snake += 1  # Suurendame mao pikkust
            score += 10  # Suurendame skoori
            eat_sound.play()  # Mängime heli

        if x1 == bonusx and y1 == bonusy:  # Kui madu sööb boonustoitu
            bonusx = round(random.randrange(0, screen_width - snake_size) / 40.0) * 40.0  # Määrame uue boonustoitu x-koordinaadi
            bonusy = round(random.randrange(0, screen_height - snake_size) / 40.0) * 40.0  # Määrame uue boonustoitu y-koordinaadi
            Length_of_snake += 2  # Suurendame mao pikkust rohkem
            score += 50  # Suurendame skoori rohkem
            bonus_sound.play()  # Mängime heli

        clock.tick(snake_speed)  # Piirame mängu kiiruse

    pygame.quit()  # Sulgeme pygame'i
    quit()  # Lõpetame programmi

# Loome mänguakna ja käivitame mängu
screen = pygame.display.set_mode((screen_width, screen_height))  # Loome mänguakna
pygame.display.set_caption('Snake Game')  # Määrame mänguakna pealkirja
gameLoop()  # Käivitame mängu
