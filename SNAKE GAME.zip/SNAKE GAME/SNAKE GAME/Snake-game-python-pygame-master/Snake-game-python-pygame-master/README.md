# Snake-game-python-pygame
A simple remake of classic arcade game of Snake in python using pygame module

Requirements:
==============================================================
1. Python 3.4.3
2. Pygame 1.9.2

Usage:
==============================================================

Linux:
--------------------------------------------------------------
1. Open the terminal and go to the game's base directory
2. Set executable permission for the file main.py
  `chmod u+x main.py`
3. Run the main.py file
  `./main.py`

Windows:
---------------------------------------------------------------
1. Open the command prompt and go to the game's base directory
2. Use `python main.py`

or

1. Open the python3 IDLE  
2. From the IDLE open the main.py file and run it.
