# -*- coding: utf-8 -*-
"""
Created on Tue May 26 19:42:43 2015

@author: sandhan
"""
import pygame

RED = pygame.Color(255,0,0)
BLUE = pygame.Color(0,0,255)
WHITE = pygame.Color(255,255,255)