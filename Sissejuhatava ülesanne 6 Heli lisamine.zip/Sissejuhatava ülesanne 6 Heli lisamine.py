import pygame
import random
import sys

# Initsialiseeri pygame
pygame.init()

# Seadista akna suurus
screen_width = 680
screen_height = 480
pygame.display.set_mode((screen_width, screen_height))

# Lae helid
pygame.mixer.music.load('music/jump.wav')

# Loo esitlusloendi helid
sounds = ['snd1.mp3', 'snd2.mp3']

# Määra helitugevus (0.0 - 1.0 vahemikus)
pygame.mixer.music.set_volume(0.2)

# Mängi heli kohe alguses
pygame.mixer.music.play()

# Heliefektide jaoks loo heliobjekt
hit_sound = pygame.mixer.Sound('music/Hit.wav')

# Mängi suvalist heli esitlusloendist
def play_random_sound():
    pygame.mixer.music.load('music/' + random.choice(sounds))
    pygame.mixer.music.play()

# Lõpmatu tsükkel, et pygame akna saaks lahti hoida
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            hit_sound.play()  # Mängib heliefekti "Hit.wav" igal hiireklahvi vajutusel
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                play_random_sound()  # Mängib suvalist helifaili esitlusloendist, kui vajutatakse tühikuklahvi

# Pärast tsükli lõppu sulge pygame
pygame.quit()
