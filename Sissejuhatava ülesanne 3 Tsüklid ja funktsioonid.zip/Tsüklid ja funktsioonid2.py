import pygame
import sys
import random 
pygame.init()   # Pygame'i algseadistus

# Värvid
red = [255, 0, 0]
green = [0, 255, 0]
blue = [0, 0, 255]
pink = [255, 153, 255]
light_green = [153, 255, 153]

# Ekraani seaded
screen=pygame.display.set_mode([640,480])  # Määrame ekraani suuruse
pygame.display.set_caption("Harjutamine")  # Määrame akna pealkirja
screen.fill(light_green)  # Täidame ekraani heleda rohelise värviga

# Funktsioon maja joonistamiseks
def drawHouse(x, y, width, height, screen, color):
    # Punktid, mis moodustavad maja kontuuri
    points = [(x, y - ((3/4.0) * height)), (x, y), (x + width, y), (x + width, y - (3/4.0) * height), 
        (x, y - ((3/4.0) * height)), (x + width / 2.0, y - height), (x + width, y - (3/4.0) * height)]
    lineThickness = 2  # Joonise paksus
    pygame.draw.lines(screen, color, False, points, lineThickness)  # Joonistame maja

# Kutsume välja funktsiooni, et joonistada maja
drawHouse(100, 400, 300, 200, screen, red)

pygame.display.flip()  # Ekraani värskendamine

while True:  # Lõpmatu tsükkel, et aken jääks avatuks
    for event in pygame.event.get():  # Sündmuste käsitlemine
        if event.type == pygame.QUIT:  # Kui sulgeb
            pygame.quit()  # Lõpetab pygame'i
