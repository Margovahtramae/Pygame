import pygame
import random
import sys
pygame.init()  # Pygame'i algseadistus

# Värvid
red = [255, 0, 0]
light_green = [153, 255, 153]

# Ekraani seaded
screen = pygame.display.set_mode([640, 480])  # Määrame ekraani suuruse
pygame.display.set_caption("Harjutamine")  # Määrame akna pealkirja
screen.fill(light_green)  # Täidame ekraani heleda rohelise värviga

# Joonistame punaseid ruute juhuslikes kohtades
for i in range(1, 10):
    x = random.randint(0, 620)  # Juhuslik x-koordinaat
    y = random.randint(0, 460)  # Juhuslik y-koordinaat
    pygame.draw.rect(screen, red, [x, y, 20, 20])  # Joonistame punase ruudu

pygame.display.flip()  # Ekraani värskendamine

while True:  # Lõpmatu tsükkel, et aken jääks avatuks
    for event in pygame.event.get():  # Sündmuste käsitlemine
        if event.type == pygame.QUIT:  # Kui sulgeb
            pygame.quit()  # Lõpetab pygame'i
