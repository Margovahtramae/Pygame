import pygame

pygame.init()

screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("Lumemees - Margo-Marten Vahtramäe")

# Taust - helesinine
screen.fill([173, 216, 230])

# Joonistame lumememmele keha
pygame.draw.circle(screen, [255, 255, 255], [150, 80], 30, 0)
pygame.draw.circle(screen, [255, 255, 255], [150, 150], 40, 0)
pygame.draw.circle(screen, [255, 255, 255], [150, 240], 50, 0)

# Joonistama lumememmele silmad
pygame.draw.circle(screen, [51, 0, 0], [140, 75], 5, 0)
pygame.draw.circle(screen, [51, 0, 0], [160, 75], 5, 0)

# Joonistame lumememmele õnarzi nina (võrdhaarne kolmnurk)
tipp1 = [150, 80 - 20 + 45]
tipp2 = [140, 80 - 40 + 45]
tipp3 = [160, 80 - 40 + 45]
pygame.draw.polygon(screen, [255, 165, 0], [tipp1, tipp2, tipp3], 0)

# Käed
pygame.draw.line(screen, [139, 69, 19], [120, 120], [100, 150], 5)
pygame.draw.line(screen, [139, 69, 19], [180, 120], [200, 150], 5)

# Nööbid
pygame.draw.circle(screen, [0, 0, 0], [150, 120], 3)
pygame.draw.circle(screen, [0, 0, 0], [150, 150], 3)
pygame.draw.circle(screen, [0, 0, 0], [150, 180], 3)

# Müts
pygame.draw.polygon(screen, [128, 0, 0], [[130, 50], [170, 50], [150, 20]], 0)
pygame.draw.rect(screen, [128, 0, 0], [140, 20, 20, 20], 0)

# Käes hari
pygame.draw.line(screen, [128, 128, 128], [205, 150], [230, 200], 8)
kolmnurk_tipud = [[265, 210], [230, 200], [220, 220]]
pygame.draw.polygon(screen, [128, 128, 128], kolmnurk_tipud, 0)
pygame.draw.line(screen, [128, 128, 128], [220, 230], [230, 200], 6)
pygame.draw.line(screen, [128, 128, 128], [225, 235], [235, 210], 6)
pygame.draw.line(screen, [128, 128, 128], [255, 210], [270, 215], 6)
pygame.draw.line(screen, [128, 128, 128], [240, 210], [260, 220], 6)
pygame.draw.line(screen, [128, 128, 128], [250, 230], [230, 200], 6)
pygame.draw.line(screen, [128, 128, 128], [240, 230], [230, 200], 6)
pygame.draw.line(screen, [128, 128, 128], [190, 155], [215, 150], 5)

# Päike
pygame.draw.circle(screen, [255, 255, 0], [250, 50], 30)
pygame.draw.line(screen, [255, 255, 0], [270, 20], [250, 80], 3)
pygame.draw.line(screen, [255, 255, 0], [200, 50], [280, 50], 3)
pygame.draw.line(screen, [255, 255, 0], [210, 30], [270, 70], 3)
pygame.draw.line(screen, [255, 255, 0], [290, 30], [230, 70], 3)

# Pilved
pygame.draw.circle(screen, [255, 255, 255], [60, 50], 20)
pygame.draw.circle(screen, [255, 255, 255], [80, 45], 25)
pygame.draw.circle(screen, [255, 255, 255], [100, 50], 20)

pygame.draw.circle(screen, [255, 255, 255], [210, 80], 20)
pygame.draw.circle(screen, [255, 255, 255], [230, 75], 25)
pygame.draw.circle(screen, [255, 255, 255], [250, 80], 20)

pygame.draw.circle(screen, [255, 255, 255], [30, 200], 20)
pygame.draw.circle(screen, [255, 255, 255], [50, 195], 25)
pygame.draw.circle(screen, [255, 255, 255], [70, 200], 20)

pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
