import pygame  
pygame.init()  # pygame'i algseadistus

screen = pygame.display.set_mode([300, 500])  # Akna mõõtmed
pygame.display.set_caption("Valgusfoor - Margo-Marten Vahtramäe")  # Akna pealkiri
screen.fill([0, 0, 0])  # Ekraani täitmine musta värviga

# Punase tule ringi joonistamine
pygame.draw.circle(screen, [204, 41, 0], [150, 47], 28, 0)
# Kollase tule ringi joonistamine
pygame.draw.circle(screen, [255, 255, 0], [150, 107], 28, 0)
# Rohelise tule ringi joonistamine
pygame.draw.circle(screen, [51, 204, 51], [150, 167], 28, 0)

# Halli posti joonistamine
pygame.draw.rect(screen, [128, 128, 128], [111, 10, 80, 200], 2)
# Halli posti täitmine
pygame.draw.rect(screen, [128, 128, 128], [145, 210, 15, 300], 0)
# Kolmnurga joonistamine
pygame.draw.polygon(screen, [128, 128, 128], [[135, 445], [168, 445], [200, 500], [100, 500]], 2)
# Kolmnurga täitmine
pygame.draw.polygon(screen, [0, 0, 255], [[135, 445], [168, 445], [180, 470], [122, 470]], 0)
# Musta kolmnurga joonistamine
pygame.draw.polygon(screen, [0, 0, 0], [[180, 470], [122, 470], [135, 485], [168, 485]], 0)
# Valge kolmnurga joonistamine
pygame.draw.polygon(screen, [255, 255, 255], [[115, 485], [188, 485], [198, 500], [105, 500]], 0)

pygame.display.flip()  # Ekraani värskendamine

while True:  # Lõpmatu tsükkel, et aken jääks avatuks
    for event in pygame.event.get():  # Sündmuste käsitlemine
        if event.type == pygame.QUIT:  # Kui sulgeb
            pygame.quit()  # Lõpetab pygame'i
