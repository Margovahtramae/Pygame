import pygame
pygame.init()
#ekraani seaded
screen=pygame.display.set_mode([640,480])
pygame.display.set_caption("Harjutamine")
screen.fill([204, 255, 204])

#Lisame pildid
panda = pygame.image.load("panda.jpg")
panda = pygame.transform.scale(panda, [640, 480])
screen.blit(panda,[0,0])

happy = pygame.image.load("happy.jpg")
happy = pygame.transform.scale(happy, [200, 120])
screen.blit(happy,[420,60])

# Seab muutuja "running" väärtuseks "True"
running = True


# Mängutsükkel
while running:
    # Käsitseb sündmusi
    for event in pygame.event.get():
        # Kui kasutaja vajutab sulgemisnuppu
        if event.type == pygame.QUIT:
            # Muudab muutuja "running" väärtuseks "False", mis peatab mängutsükli
            running = False

    pygame.display.flip()

# Lõpetab pygame'i kasutamise
pygame.quit()