import pygame #laeme pygame teegi
pygame.init() #pygame käivitamine

screen=pygame.display.set_mode([300,300]) #tekitame akna 300x300
pygame.display.set_caption("Lumemees - Margo-Marten Vahtramäe") #kuvame erkaani nime

# Joonistame lumememmele keha
pygame.draw.circle(screen, [255, 255, 255], [150,80], 30, 0)
pygame.draw.circle(screen, [255, 255, 255], [150,150], 40, 0)
pygame.draw.circle(screen, [255, 255, 255], [150,240], 50, 0)

# Joonistama lumememmele silmad 
pygame.draw.circle(screen, [51, 0, 0], [140,75], 5, 0)
pygame.draw.circle(screen, [51, 0, 0], [160,75], 5, 0)

 # Joonistame lumememmele õranzi nina (võrdhaarne kolmnurk)
tipp1 = [150, 80 - 20 + 45]  
tipp2 = [140, 80 - 40 + 45]  
tipp3 = [160, 80 - 40 + 45]

pygame.draw.polygon(screen, [255, 165, 0], [tipp1, tipp2, tipp3], 0) # Joonistame täidetud oranži kolmnurga

pygame.display.flip() #värskendame ekraani

while True: #algatame lõpmatu tsükli, et aken püsiks avatud
    for event in pygame.event.get(): #kontrollime sündmuseid
        if event.type == pygame.QUIT: #kui sündmuse tüüp on QUIT
            pygame.quit() #lõpetame pygame