import pygame  #laeme pygame teegi
pygame.init() #pygame käivitamine

screen = pygame.display.set_mode([300, 300])  #tekitame akna 300x300
pygame.display.set_caption("Valgusfoor - Margo-Marten Vahtramäe") #kuvame erkaani nime
screen.fill([0, 0, 0])  # Täidame ekraani musta värviga

# Joonistame halli ristküliku
pygame.draw.rect(screen, [179, 179, 179], [95, 35, 110, 210], 1)

# Joonistame punase ringi
pygame.draw.circle(screen, [204, 41, 0], [150, 80], 28, 0)
# Joonistame kollase ringi
pygame.draw.circle(screen, [255, 255, 0], [150, 140], 28, 0)
# Joonistame rohelise ringi
pygame.draw.circle(screen, [51, 204, 51], [150, 200], 28, 0)

pygame.display.flip()  # Värskendame ekraani

while True: #algatame lõpmatu tsükli, et aken püsiks avatud
    for event in pygame.event.get(): #kontrollime sündmuseid
        if event.type == pygame.QUIT: #kui sündmuse tüüp on QUIT
            pygame.quit() #lõpetame pygame
